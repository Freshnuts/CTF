#!/bin/sh

cd `dirname $0`
timeout --foreground 90s ./baba_pwn_game
