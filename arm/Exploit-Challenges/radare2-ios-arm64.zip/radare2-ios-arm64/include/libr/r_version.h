#ifndef R_VERSION_H
#define R_VERSION_H 1
#define R2_VERSION_COMMIT 1
#define R2_GITTAP "1.2.0-git"
#define R2_GITTIP "5d4226c015c116efd212ecaf1715aee7983fc169"
#define R2_BIRTH "2016-12-26"
#endif
